package nbComplexe;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		ComplexNumber x = new ComplexNumber(1, 0);
		System.out.println(x); // 1|
		System.out.println(x.isPureReal()); // true
		System.out.println(x.isPureImaginary()); // false

		ComplexNumber y = new ComplexNumber(0, 1);
		System.out.println(y); // |1
		System.out.println(y.getConjugate()); // |-1
		System.out.println(y.isPureReal()); // false
		System.out.println(y.isPureImaginary()); // true

		System.out.println(x.equals(y)); // false
		System.out.println(x.equals(x.getConjugate())); // true

		System.out.println(new ComplexNumber(1, 2)); // 1|2

		ComplexNumber z = new ComplexNumber(1); // si on utilise le constructeur à un argument, on créé un réel pur
		System.out.println(z); // 1|
		System.out.println(x.equals(z)); // true

		var set = new HashSet<ComplexNumber>();
		set.add(x);
		set.add(z);
		System.out.println(set); // [1|]
		
		
		
		List<ComplexNumber> numbers = new ArrayList<>();
		numbers.add(ComplexNumber.REAL_ONE);
		numbers.add(ComplexNumber.IMAGINARY_ONE);
		numbers.add(ComplexNumber.IMAGINARY_ONE.getConjugate());
		numbers.add(new ComplexNumber(42, -37));
		numbers.sort(null);
		System.out.println(numbers); // [|-1, |1, 1|, 42|-37]
	}

}
