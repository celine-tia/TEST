package nbComplexe;

import java.util.Objects;

public class ComplexNumber implements Comparable<ComplexNumber>{
	private final int a;
	private final int b;
	public static final ComplexNumber ZERO = new ComplexNumber(0);
	public static final ComplexNumber REAL_ONE = new ComplexNumber(1);
	public static final ComplexNumber IMAGINARY_ONE = new ComplexNumber(0, 1);

	// a = int, composante reelle
	// b = int, composante imaginaire

	public ComplexNumber(int a, int b) {
		this.b = b;
		this.a = a;

	}

	public ComplexNumber(int a) {
		this.b = 0;
		this.a = a;
	}

	public int getRealPart() {
		return a;
	}

	public int getImaginaryPart() {
		return b;
	}

	public boolean isPureReal() {
		if (b == 0) {
			return true;
		}
		return false;
	}

	public boolean isPureImaginary() {
		if (a == 0) {
			return true;
		}
		return false;
	}

	public String toString() {
		if (this.isPureReal()) {
			return a + "|";
		}
		if (this.isPureImaginary()) {
			return "|" + b;
		}
		if (a == 0 && b == 0) {
			return 0 + "|";
		} else {
			return a + "|" + b;
		}
	}

	public ComplexNumber getConjugate() {
		int b = this.getImaginaryPart();
		b = -b;
		return new ComplexNumber(this.getRealPart(), b);
	}

	@Override
	public boolean equals(Object o) {
		if (!(o instanceof ComplexNumber))
			return false;
		ComplexNumber cp = (ComplexNumber) o;
		return (a == cp.a) && (b == cp.b);
	}

	@Override
	public int hashCode() {
		return Objects.hash(a, b);
	}

	public int compareTo(ComplexNumber c) {
		if (a == c.a) {
			return b - c.b;
		}
		return a - c.a;
	}
	
	
}
